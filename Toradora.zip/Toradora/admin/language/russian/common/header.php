<?php
// Heading
$_['heading_title']        		= 'ocStore';

// Text
$_['text_order']          		= 'Заказы';
$_['text_processing_status']    = 'В процессе';
$_['text_complete_status']      = 'Завершено';
$_['text_customer']          	= 'Покупатели';
$_['text_online']          		= 'Онлайн';
$_['text_approval']          	= 'В ожидании';
$_['text_product']          	= 'Товары';
$_['text_stock']          		= 'Нет в наличии';
$_['text_review']          		= 'Отзывы';
$_['text_return']          		= 'Возвраты';
$_['text_affiliate']          	= 'Партнерская программа';
$_['text_store']          		= 'Магазины';
$_['text_front']          		= 'Магазин';
$_['text_help']          		= 'Помощь';
$_['text_homepage']          	= 'Главная';
$_['text_support']          	= 'Форум ocStore';
$_['text_documentation']        = 'Документация';
$_['text_logout']          		= 'Выход';